import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        System.out.println("Enter your vehicle type:");
        System.out.println("Car, truck, bus, motorcycle");

        Scanner scan = new Scanner(System.in);

        String type = scan.nextLine();
        int premium = 0;

        switch (type){
            case "Cae":
                premium = 200;
                break;
            case "truck":
                premium = 300;
                break;
            case "bus":
                premium = 400;
                break;
            case "motorcycle":
                System.out.println("Enter your motorcycle type:");
                System.out.println("1 (low power), 2 (medium), 3(high)");
                String motorCycleType = scan.nextLine();
                int motorcycleInt = Integer.parseInt(motorCycleType);

                switch (motorcycleInt){
            case 1:
                premium = 300;
                break;
                    case 2:
                        premium = 500;
                        break;
                    case 3:
                        premium = 600;
                        break;
                    default:
                        System.out.println("Unknow vehicle type");

                }
               scan.close();
                System.out.println("The premium is $" + premium);
        }
    }
}